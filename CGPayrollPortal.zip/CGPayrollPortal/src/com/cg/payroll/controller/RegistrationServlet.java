package com.cg.payroll.controller;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
@WebServlet("/registration")
public class RegistrationServlet extends HttpServlet {
	private PayrollServices services;
	private static final long serialVersionUID = 1L;
	@Override
	public void init() throws ServletException {
		super.init();
		services=new PayrollServicesImpl();
	}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Associate associate=new Associate(Integer.parseInt(request.getParameter("yearlyInvestmentUnder80c")), request.getParameter("firstName"), request.getParameter("lastName"), request.getParameter("department"), 
				request.getParameter("designation"), request.getParameter("panCard"),request.getParameter("emailId"), 
				new Salary(Integer.parseInt(request.getParameter("basicSalary")), Integer.parseInt(request.getParameter("epf")), Integer.parseInt(request.getParameter("companyPf"))), 
						new BankDetails(Integer.parseInt(request.getParameter("accountNumber")), request.getParameter("bankName"), request.getParameter("ifscCode")));
		int associateId=services.acceptAssociateDetails(associate);
		request.setAttribute("associateId", associateId);
		request.setAttribute("success", "Successfully registered with ID=");
		request.getRequestDispatcher("RegistrationPage.jsp").forward(request, response);
	}
@Override
public void destroy() {
     services=null;
}


}